@extends('layouts.app')

@section('content')
    <div class="text-center">
        <h1 class="text-4xl font-bold text-gray-800 mb-4">Welcome to Health Reminder</h1>
        <p class="text-xl text-gray-600 mb-6">Your personal assistant for managing health reminders, medications, and appointments.</p>
        <a href="{{ route('medications.index') }}" class="bg-indigo-600 text-white py-2 px-6 rounded-md text-lg font-semibold hover:bg-indigo-700 transition-colors">
            Get Started
        </a>
    </div>
@endsection
